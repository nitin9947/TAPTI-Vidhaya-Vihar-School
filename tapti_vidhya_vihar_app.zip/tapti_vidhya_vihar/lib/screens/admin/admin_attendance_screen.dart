import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import '../../models/models.dart';
import '../../services/database_service.dart';
import '../../utils/app_theme.dart';
import '../../widgets/common_widgets.dart';

class AdminAttendanceScreen extends StatefulWidget {
  const AdminAttendanceScreen({super.key});

  @override
  State<AdminAttendanceScreen> createState() =>
      _AdminAttendanceScreenState();
}

class _AdminAttendanceScreenState extends State<AdminAttendanceScreen> {
  String? _selectedClass;
  DateTime _selectedDate = DateTime.now();
  List<Student> _students = [];
  Map<String, bool?> _attendanceMap = {};

  @override
  void initState() {
    super.initState();
    final classes = DatabaseService.getAllClassDivisions();
    if (classes.isNotEmpty) {
      _selectedClass = classes.first;
      _load();
    }
  }

  void _load() {
    if (_selectedClass == null) return;
    final dateStr = DateFormat('yyyy-MM-dd').format(_selectedDate);
    setState(() {
      _students = DatabaseService.getStudentsByClass(_selectedClass!);
      _attendanceMap = DatabaseService.getAttendanceMapForDate(
          _selectedClass!, dateStr);
    });
  }

  @override
  Widget build(BuildContext context) {
    final classDivs = DatabaseService.getAllClassDivisions();

    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        title: const Text('Attendance Records'),
        backgroundColor: AppTheme.primary,
      ),
      body: Column(
        children: [
          // Controls
          Container(
            color: Colors.white,
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                if (classDivs.isNotEmpty)
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: classDivs.map((cd) {
                        return Padding(
                          padding: const EdgeInsets.only(right: 6),
                          child: ClassChip(
                            label: cd,
                            selected: _selectedClass == cd,
                            onTap: () {
                              setState(() => _selectedClass = cd);
                              _load();
                            },
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                const SizedBox(height: 12),
                GestureDetector(
                  onTap: () async {
                    final d = await showDatePicker(
                      context: context,
                      initialDate: _selectedDate,
                      firstDate: DateTime(2020),
                      lastDate: DateTime.now(),
                      builder: (ctx, child) => Theme(
                        data: ThemeData(
                            colorScheme: const ColorScheme.light(
                                primary: AppTheme.primary)),
                        child: child!,
                      ),
                    );
                    if (d != null) {
                      setState(() => _selectedDate = d);
                      _load();
                    }
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 10),
                    decoration: BoxDecoration(
                      color: AppTheme.primary.withOpacity(0.06),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                          color: AppTheme.primary.withOpacity(0.2)),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          DateFormat('EEEE, dd MMMM yyyy')
                              .format(_selectedDate),
                          style: GoogleFonts.roboto(
                            fontWeight: FontWeight.w600,
                            color: AppTheme.primary,
                          ),
                        ),
                        const Icon(Icons.calendar_today,
                            color: AppTheme.primary, size: 18),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Summary chips
          if (_students.isNotEmpty)
            Container(
              color: Colors.white,
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
              child: Row(
                children: [
                  _summaryChip(
                    'Present',
                    _attendanceMap.values.where((v) => v == true).length,
                    AppTheme.presentColor,
                  ),
                  const SizedBox(width: 10),
                  _summaryChip(
                    'Absent',
                    _attendanceMap.values.where((v) => v == false).length,
                    AppTheme.absentColor,
                  ),
                  const SizedBox(width: 10),
                  _summaryChip(
                    'Unmarked',
                    _attendanceMap.values.where((v) => v == null).length,
                    Colors.grey,
                  ),
                ],
              ),
            ),

          const GoldDivider(),

          Expanded(
            child: _students.isEmpty
                ? Center(
                    child: Text(
                      classDivs.isEmpty
                          ? 'No classes created'
                          : 'No students in this class',
                      style: GoogleFonts.roboto(
                          color: AppTheme.textSecondary),
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: _students.length,
                    itemBuilder: (ctx, i) {
                      final s = _students[i];
                      final status = _attendanceMap[s.studentId];
                      return Card(
                        margin: const EdgeInsets.only(bottom: 8),
                        child: ListTile(
                          leading: StudentAvatar(
                              photoPath: s.photoPath,
                              name: s.name,
                              radius: 20),
                          title: Text(s.name,
                              style: GoogleFonts.roboto(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 14)),
                          subtitle: Text(s.studentId,
                              style: GoogleFonts.roboto(
                                  fontSize: 11,
                                  color: AppTheme.textSecondary)),
                          trailing: AttendanceBadge(isPresent: status),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _summaryChip(String label, int count, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Text(
        '$label: $count',
        style: GoogleFonts.roboto(
          fontSize: 12,
          fontWeight: FontWeight.w600,
          color: color,
        ),
      ),
    );
  }
}
