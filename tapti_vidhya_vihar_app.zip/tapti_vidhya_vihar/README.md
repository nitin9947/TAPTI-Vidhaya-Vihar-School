# 🏫 Tapti Vidhya Vihar — School Management App

A complete Flutter mobile app for school management with offline-first local storage (Hive), role-based access control, attendance tracking, and student photo management.

---

## 📁 Project Structure

```
tapti_vidhya_vihar/
├── lib/
│   ├── main.dart                          ← App entry point
│   ├── utils/
│   │   └── app_theme.dart                 ← Colors, fonts, theme
│   ├── models/
│   │   ├── models.dart                    ← Hive data models
│   │   └── models.g.dart                  ← Hive type adapters (hand-written)
│   ├── services/
│   │   ├── database_service.dart          ← All Hive CRUD operations
│   │   └── auth_service.dart              ← Login / session management
│   ├── widgets/
│   │   └── common_widgets.dart            ← Reusable UI components
│   └── screens/
│       ├── login_screen.dart              ← Login page (Admin/Teacher + Student tabs)
│       ├── admin/
│       │   ├── admin_dashboard.dart       ← Super Admin home
│       │   ├── class_management_screen.dart   ← Create/manage classes & divisions
│       │   ├── teacher_management_screen.dart ← Add/edit/delete teachers
│       │   ├── admin_student_list_screen.dart ← View all students
│       │   └── admin_attendance_screen.dart   ← View attendance records
│       ├── teacher/
│       │   ├── teacher_dashboard.dart     ← Teacher home
│       │   ├── add_student_screen.dart    ← Enroll student + photo upload
│       │   ├── student_list_screen.dart   ← Teacher's student list
│       │   ├── student_detail_screen.dart ← Full student profile
│       │   └── attendance_screen.dart     ← Mark/view attendance
│       └── student/
│           └── student_dashboard.dart     ← Student read-only profile + attendance
├── assets/
│   └── images/
│       └── school_logo.png               ← School logo (already included)
├── android/
│   └── app/src/main/
│       ├── AndroidManifest.xml           ← Camera & storage permissions
│       └── res/xml/file_paths.xml        ← FileProvider config
└── pubspec.yaml                          ← Dependencies
```

---

## 🚀 Setup Instructions

### 1. Prerequisites
- Flutter SDK ≥ 3.0.0 installed
- Android Studio or VS Code with Flutter plugin
- Android/iOS device or emulator

### 2. Clone / Copy the Project
Place the entire `tapti_vidhya_vihar/` folder wherever you keep Flutter projects.

### 3. Install Dependencies
```bash
cd tapti_vidhya_vihar
flutter pub get
```

### 4. Run the App
```bash
flutter run
```

> For release APK:
> ```bash
> flutter build apk --release
> ```
> APK will be at: `build/app/outputs/flutter-apk/app-release.apk`

---

## 🔐 Login Credentials

### Super Admin
| Field    | Value  |
|----------|--------|
| Username | nitin  |
| Password | 1234   |

### Teacher
Teachers are created by Nitin (Super Admin). Use the username/password set during creation.

### Student
Students log in using their **Unique ID** (e.g. `10A101`). No password required.

---

## 🎯 Feature Walkthrough

### As Super Admin (Nitin):
1. **Login** → Enter `nitin` / `1234`
2. **Manage Classes** → Create classes (8, 9, 10...) and divisions (A, B, C...)
3. **Manage Teachers** → Add teachers with username/password and optional class assignment
4. **View All Students** → Browse/search all enrolled students
5. **View Attendance** → Select any class/date to see attendance records

### As Teacher:
1. **Login** → Enter teacher username/password (created by admin)
2. **Add Students** → Enroll students, select class, capture photo
3. **Mark Attendance** → Tap P/A for each student, press SAVE
4. **View Reports** → Monthly attendance summaries per student

### As Student:
1. **Login** → Enter Unique ID (e.g. `10A101`)
2. **View Profile** → Name, class, photo, unique ID
3. **View Attendance** → Monthly records with percentage

---

## 🎨 Theme Colors (from School Logo)

| Purpose         | Color       |
|----------------|-------------|
| Primary         | `#8B1A1A` (Deep Crimson) |
| Primary Dark    | `#5C0E0E`   |
| Primary Light   | `#B03030`   |
| Gold Accent     | `#D4A843`   |
| Present         | `#2E7D32` (Green) |
| Absent          | `#C62828` (Red)   |
| Background      | `#FAF8F5`   |
| Font            | Roboto (Google Fonts) |

---

## 💾 Data Storage

All data is stored **locally on device** using Hive (NoSQL key-value database):

| Box Name     | Contents                          |
|--------------|-----------------------------------|
| `classes`    | Class names + divisions           |
| `teachers`   | Teacher credentials + assignments |
| `students`   | Student records + photo paths     |
| `attendance` | Daily attendance records          |

Student photos are saved to the app's private documents directory:
`/data/user/0/<package>/files/student_photos/`

Data **persists** across app restarts and device reboots.

---

## 📱 Unique Student ID Format

```
[ClassName][Division][AutoNumber]
  └─ e.g.:  10A101, 9B205, 8C310
```
- Auto-increments starting from 101
- Guaranteed unique within the app
- Students use this ID to log in

---

## 🛠 Dependencies

| Package           | Version | Purpose                    |
|-------------------|---------|----------------------------|
| hive              | ^2.2.3  | Local database             |
| hive_flutter      | ^1.1.0  | Hive + Flutter integration |
| image_picker      | ^1.0.4  | Camera & gallery access    |
| uuid              | ^4.1.0  | Unique ID generation       |
| intl              | ^0.18.1 | Date formatting            |
| path_provider     | ^2.1.1  | App documents directory    |
| path              | ^1.8.3  | Path manipulation          |
| google_fonts      | ^6.1.0  | Roboto font                |

---

## ⚠️ Troubleshooting

**Build error: `models.g.dart` not found**
→ The file is already included manually. No need to run `build_runner`.

**Images not showing**
→ Ensure camera/storage permissions are granted on device. On Android 13+, the app requests `READ_MEDIA_IMAGES`.

**Google Fonts not loading**
→ Run the app with internet connection once to cache fonts. After that, works offline.

**Hive type already registered**
→ This means the app restarted without clearing adapters. Hot restart (not hot reload) fixes this during development.

---

## 📦 Build APK for Distribution

```bash
# Debug APK (for testing)
flutter build apk --debug

# Release APK (for distribution)
flutter build apk --release --split-per-abi
```

The `--split-per-abi` flag creates separate smaller APKs for arm64, armeabi-v7a, and x86_64.

---

*Built for Tapti Vidhya Vihar School — All data stored locally, no internet required after first run.*
