import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';
import '../../models/models.dart';
import '../../services/auth_service.dart';
import '../../services/database_service.dart';
import '../../utils/app_theme.dart';
import '../../widgets/common_widgets.dart';

class AttendanceScreen extends StatefulWidget {
  final bool viewMode;
  const AttendanceScreen({super.key, this.viewMode = false});

  @override
  State<AttendanceScreen> createState() => _AttendanceScreenState();
}

class _AttendanceScreenState extends State<AttendanceScreen> {
  DateTime _selectedDate = DateTime.now();
  List<Student> _students = [];
  Map<String, bool?> _attendanceMap = {};
  bool _saving = false;
  String? _classDiv;

  @override
  void initState() {
    super.initState();
    final teacher = AuthService.currentUser?.teacher;
    _classDiv = teacher?.assignedClass;
    _load();
  }

  void _load() {
    if (_classDiv == null) {
      setState(() => _students = []);
      return;
    }
    final dateStr = DateFormat('yyyy-MM-dd').format(_selectedDate);
    final students = DatabaseService.getStudentsByClass(_classDiv!);
    final map = DatabaseService.getAttendanceMapForDate(_classDiv!, dateStr);
    setState(() {
      _students = students;
      _attendanceMap = map;
    });
  }

  Future<void> _saveAttendance() async {
    setState(() => _saving = true);
    final teacherId = AuthService.currentUser!.id;
    final dateStr = DateFormat('yyyy-MM-dd').format(_selectedDate);

    for (final entry in _attendanceMap.entries) {
      if (entry.value == null) continue;
      final existing =
          DatabaseService.getAttendance(entry.key, dateStr);
      if (existing != null) {
        existing.isPresent = entry.value!;
        await existing.save();
      } else {
        final rec = AttendanceRecord(
          recordId: const Uuid().v4(),
          studentId: entry.key,
          date: dateStr,
          isPresent: entry.value!,
          markedByTeacherId: teacherId,
        );
        await DatabaseService.saveAttendance(rec);
      }
    }

    setState(() => _saving = false);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Attendance saved successfully'),
        backgroundColor: AppTheme.presentColor,
      ));
    }
  }

  void _markAll(bool present) {
    setState(() {
      for (final s in _students) {
        _attendanceMap[s.studentId] = present;
      }
    });
  }

  int get _presentCount =>
      _attendanceMap.values.where((v) => v == true).length;
  int get _absentCount =>
      _attendanceMap.values.where((v) => v == false).length;
  int get _unmarkedCount =>
      _attendanceMap.values.where((v) => v == null).length;

  @override
  Widget build(BuildContext context) {
    final isToday = DateFormat('yyyy-MM-dd').format(_selectedDate) ==
        DateFormat('yyyy-MM-dd').format(DateTime.now());

    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        title: Text(widget.viewMode ? 'Attendance Report' : 'Mark Attendance'),
        backgroundColor: AppTheme.primary,
        actions: [
          if (!widget.viewMode && _students.isNotEmpty)
            TextButton(
              onPressed: _saving ? null : _saveAttendance,
              child: _saving
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(
                          color: Colors.white, strokeWidth: 2),
                    )
                  : const Text('SAVE',
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w700)),
            ),
        ],
      ),
      body: Column(
        children: [
          // ── Date picker bar ───────────────────────────────────
          Container(
            color: Colors.white,
            padding: const EdgeInsets.all(12),
            child: Column(
              children: [
                GestureDetector(
                  onTap: () async {
                    final d = await showDatePicker(
                      context: context,
                      initialDate: _selectedDate,
                      firstDate: DateTime(2020),
                      lastDate: DateTime.now(),
                      builder: (ctx, child) => Theme(
                        data: ThemeData(
                            colorScheme: const ColorScheme.light(
                                primary: AppTheme.primary)),
                        child: child!,
                      ),
                    );
                    if (d != null) {
                      setState(() => _selectedDate = d);
                      _load();
                    }
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 12),
                    decoration: BoxDecoration(
                      color: AppTheme.primary.withOpacity(0.06),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                          color: AppTheme.primary.withOpacity(0.2)),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.calendar_today,
                            color: AppTheme.primary, size: 18),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            isToday
                                ? 'Today — ${DateFormat('dd MMM yyyy').format(_selectedDate)}'
                                : DateFormat('EEEE, dd MMMM yyyy')
                                    .format(_selectedDate),
                            style: GoogleFonts.roboto(
                              fontWeight: FontWeight.w600,
                              color: AppTheme.primary,
                            ),
                          ),
                        ),
                        const Icon(Icons.expand_more,
                            color: AppTheme.primary, size: 20),
                      ],
                    ),
                  ),
                ),

                if (_classDiv != null) ...[
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      const Icon(Icons.class_,
                          size: 14, color: AppTheme.textSecondary),
                      const SizedBox(width: 6),
                      Text(
                        'Class $_classDiv  •  ${_students.length} students',
                        style: GoogleFonts.roboto(
                            fontSize: 12,
                            color: AppTheme.textSecondary),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),

          // ── Summary strip ────────────────────────────────────
          if (_students.isNotEmpty)
            Container(
              color: Colors.white,
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
              child: Row(
                children: [
                  _summaryPill('P: $_presentCount', AppTheme.presentColor),
                  const SizedBox(width: 8),
                  _summaryPill('A: $_absentCount', AppTheme.absentColor),
                  const SizedBox(width: 8),
                  _summaryPill('?: $_unmarkedCount', Colors.grey),
                  const Spacer(),
                  if (!widget.viewMode) ...[
                    TextButton(
                      onPressed: () => _markAll(true),
                      style: TextButton.styleFrom(
                          foregroundColor: AppTheme.presentColor,
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 4)),
                      child: const Text('All P',
                          style: TextStyle(fontSize: 12)),
                    ),
                    TextButton(
                      onPressed: () => _markAll(false),
                      style: TextButton.styleFrom(
                          foregroundColor: AppTheme.absentColor,
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 4)),
                      child: const Text('All A',
                          style: TextStyle(fontSize: 12)),
                    ),
                  ],
                ],
              ),
            ),

          const GoldDivider(),

          // ── Student attendance list ──────────────────────────
          Expanded(
            child: _classDiv == null
                ? _noClassWidget()
                : _students.isEmpty
                    ? Center(
                        child: Text('No students in this class',
                            style: GoogleFonts.roboto(
                                color: AppTheme.textSecondary)),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(12, 8, 12, 80),
                        itemCount: _students.length,
                        itemBuilder: (ctx, i) {
                          final s = _students[i];
                          final status = _attendanceMap[s.studentId];
                          return _AttendanceTile(
                            student: s,
                            status: status,
                            readOnly: widget.viewMode,
                            onChanged: widget.viewMode
                                ? null
                                : (v) {
                                    setState(() =>
                                        _attendanceMap[s.studentId] = v);
                                  },
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }

  Widget _summaryPill(String label, Color color) {
    return Container(
      padding:
          const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(label,
          style: GoogleFonts.roboto(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: color)),
    );
  }

  Widget _noClassWidget() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.class_outlined,
                size: 60, color: AppTheme.primary.withOpacity(0.3)),
            const SizedBox(height: 16),
            Text(
              'No class assigned',
              style: GoogleFonts.roboto(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.textSecondary),
            ),
            const SizedBox(height: 8),
            Text(
              'Ask your admin to assign you a class.',
              style: GoogleFonts.roboto(
                  fontSize: 13, color: AppTheme.textSecondary),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

// ── Individual attendance tile ─────────────────────────────────────
class _AttendanceTile extends StatelessWidget {
  final Student student;
  final bool? status;
  final bool readOnly;
  final ValueChanged<bool?>? onChanged;

  const _AttendanceTile({
    required this.student,
    required this.status,
    required this.readOnly,
    this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final isPresent = status == true;
    final isAbsent = status == false;

    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: Padding(
        padding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        child: Row(
          children: [
            StudentAvatar(
                photoPath: student.photoPath,
                name: student.name,
                radius: 20),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(student.name,
                      style: GoogleFonts.roboto(
                          fontWeight: FontWeight.w600, fontSize: 14)),
                  Text(student.studentId,
                      style: GoogleFonts.roboto(
                          fontSize: 11,
                          color: AppTheme.textSecondary)),
                ],
              ),
            ),
            if (readOnly)
              AttendanceBadge(isPresent: status)
            else
              Row(
                children: [
                  // Present button
                  GestureDetector(
                    onTap: () =>
                        onChanged?.call(isPresent ? null : true),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 180),
                      width: 44,
                      height: 36,
                      decoration: BoxDecoration(
                        color: isPresent
                            ? AppTheme.presentColor
                            : AppTheme.presentColor.withOpacity(0.08),
                        borderRadius: const BorderRadius.horizontal(
                            left: Radius.circular(8)),
                        border: Border.all(
                          color: isPresent
                              ? AppTheme.presentColor
                              : AppTheme.presentColor.withOpacity(0.3),
                        ),
                      ),
                      child: Center(
                        child: Text(
                          'P',
                          style: GoogleFonts.roboto(
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                            color: isPresent
                                ? Colors.white
                                : AppTheme.presentColor,
                          ),
                        ),
                      ),
                    ),
                  ),
                  // Absent button
                  GestureDetector(
                    onTap: () =>
                        onChanged?.call(isAbsent ? null : false),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 180),
                      width: 44,
                      height: 36,
                      decoration: BoxDecoration(
                        color: isAbsent
                            ? AppTheme.absentColor
                            : AppTheme.absentColor.withOpacity(0.08),
                        borderRadius: const BorderRadius.horizontal(
                            right: Radius.circular(8)),
                        border: Border.all(
                          color: isAbsent
                              ? AppTheme.absentColor
                              : AppTheme.absentColor.withOpacity(0.3),
                        ),
                      ),
                      child: Center(
                        child: Text(
                          'A',
                          style: GoogleFonts.roboto(
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                            color: isAbsent
                                ? Colors.white
                                : AppTheme.absentColor,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }
}
