// GENERATED - Hand-written adapters to avoid build_runner requirement
part of 'models.dart';

// ─── SchoolClass Adapter ─────────────────────────────────────────
class SchoolClassAdapter extends TypeAdapter<SchoolClass> {
  @override
  final int typeId = 0;

  @override
  SchoolClass read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return SchoolClass(
      classId: fields[0] as String,
      className: fields[1] as String,
      divisions: (fields[2] as List).cast<String>(),
    );
  }

  @override
  void write(BinaryWriter writer, SchoolClass obj) {
    writer
      ..writeByte(3)
      ..writeByte(0)
      ..write(obj.classId)
      ..writeByte(1)
      ..write(obj.className)
      ..writeByte(2)
      ..write(obj.divisions);
  }
}

// ─── Teacher Adapter ─────────────────────────────────────────────
class TeacherAdapter extends TypeAdapter<Teacher> {
  @override
  final int typeId = 1;

  @override
  Teacher read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return Teacher(
      teacherId: fields[0] as String,
      name: fields[1] as String,
      username: fields[2] as String,
      password: fields[3] as String,
      assignedClass: fields[4] as String?,
      photoPath: fields[5] as String?,
    );
  }

  @override
  void write(BinaryWriter writer, Teacher obj) {
    writer
      ..writeByte(6)
      ..writeByte(0)
      ..write(obj.teacherId)
      ..writeByte(1)
      ..write(obj.name)
      ..writeByte(2)
      ..write(obj.username)
      ..writeByte(3)
      ..write(obj.password)
      ..writeByte(4)
      ..write(obj.assignedClass)
      ..writeByte(5)
      ..write(obj.photoPath);
  }
}

// ─── Student Adapter ─────────────────────────────────────────────
class StudentAdapter extends TypeAdapter<Student> {
  @override
  final int typeId = 2;

  @override
  Student read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return Student(
      studentId: fields[0] as String,
      name: fields[1] as String,
      className: fields[2] as String,
      division: fields[3] as String,
      photoPath: fields[4] as String?,
      addedByTeacherId: fields[5] as String,
    );
  }

  @override
  void write(BinaryWriter writer, Student obj) {
    writer
      ..writeByte(6)
      ..writeByte(0)
      ..write(obj.studentId)
      ..writeByte(1)
      ..write(obj.name)
      ..writeByte(2)
      ..write(obj.className)
      ..writeByte(3)
      ..write(obj.division)
      ..writeByte(4)
      ..write(obj.photoPath)
      ..writeByte(5)
      ..write(obj.addedByTeacherId);
  }
}

// ─── AttendanceRecord Adapter ─────────────────────────────────────
class AttendanceRecordAdapter extends TypeAdapter<AttendanceRecord> {
  @override
  final int typeId = 3;

  @override
  AttendanceRecord read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return AttendanceRecord(
      recordId: fields[0] as String,
      studentId: fields[1] as String,
      date: fields[2] as String,
      isPresent: fields[3] as bool,
      markedByTeacherId: fields[4] as String,
    );
  }

  @override
  void write(BinaryWriter writer, AttendanceRecord obj) {
    writer
      ..writeByte(5)
      ..writeByte(0)
      ..write(obj.recordId)
      ..writeByte(1)
      ..write(obj.studentId)
      ..writeByte(2)
      ..write(obj.date)
      ..writeByte(3)
      ..write(obj.isPresent)
      ..writeByte(4)
      ..write(obj.markedByTeacherId);
  }
}
