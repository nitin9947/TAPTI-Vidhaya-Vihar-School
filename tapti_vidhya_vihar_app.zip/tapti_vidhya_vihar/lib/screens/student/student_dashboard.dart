import 'dart:io';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import '../../models/models.dart';
import '../../services/auth_service.dart';
import '../../services/database_service.dart';
import '../../utils/app_theme.dart';
import '../../widgets/common_widgets.dart';
import '../login_screen.dart';

class StudentDashboard extends StatefulWidget {
  const StudentDashboard({super.key});

  @override
  State<StudentDashboard> createState() => _StudentDashboardState();
}

class _StudentDashboardState extends State<StudentDashboard> {
  late Student _student;
  List<AttendanceRecord> _records = [];
  Map<String, int> _summary = {};
  final _now = DateTime.now();
  int _selectedMonth = DateTime.now().month;
  int _selectedYear = DateTime.now().year;

  @override
  void initState() {
    super.initState();
    _student = AuthService.currentUser!.student!;
    _load();
  }

  void _load() {
    // Refresh student from DB in case it was updated
    final fresh =
        DatabaseService.getStudentById(_student.studentId);
    if (fresh != null) _student = fresh;

    final records =
        DatabaseService.getAttendanceForStudent(_student.studentId);
    final summary = DatabaseService.getMonthlyAttendanceSummary(
        _student.studentId, _selectedYear, _selectedMonth);
    setState(() {
      _records = records;
      _summary = summary;
    });
  }

  List<AttendanceRecord> get _filteredRecords {
    final monthStr =
        '$_selectedYear-${_selectedMonth.toString().padLeft(2, '0')}';
    return _records
        .where((r) => r.date.startsWith(monthStr))
        .toList()
      ..sort((a, b) => b.date.compareTo(a.date));
  }

  double get _attendancePct {
    if (_summary['total'] == 0 || _summary['total'] == null) return 0;
    return (_summary['present']! / _summary['total']!) * 100;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      body: CustomScrollView(
        slivers: [
          // ── Hero Header ──────────────────────────────────────
          SliverAppBar(
            expandedHeight: 260,
            pinned: true,
            backgroundColor: AppTheme.primary,
            automaticallyImplyLeading: false,
            actions: [
              IconButton(
                icon: const Icon(Icons.logout, color: Colors.white),
                onPressed: () {
                  AuthService.logout();
                  Navigator.pushReplacement(context,
                      MaterialPageRoute(
                          builder: (_) => const LoginScreen()));
                },
              ),
            ],
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [AppTheme.primaryDark, AppTheme.primary],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: SafeArea(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const SizedBox(height: 36),
                      // Logo small
                      Image.asset('assets/images/school_logo.png',
                          width: 36, height: 36),
                      const SizedBox(height: 10),
                      // Student photo
                      Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                              color: AppTheme.goldLight, width: 3),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.25),
                              blurRadius: 10,
                              offset: const Offset(0, 4),
                            )
                          ],
                        ),
                        child: _student.photoPath != null &&
                                File(_student.photoPath!).existsSync()
                            ? CircleAvatar(
                                radius: 44,
                                backgroundImage: FileImage(
                                    File(_student.photoPath!)),
                              )
                            : CircleAvatar(
                                radius: 44,
                                backgroundColor:
                                    AppTheme.gold.withOpacity(0.2),
                                child: Text(
                                  _student.name[0].toUpperCase(),
                                  style: GoogleFonts.roboto(
                                      fontSize: 34,
                                      fontWeight: FontWeight.w800,
                                      color: Colors.white),
                                ),
                              ),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        _student.name,
                        style: GoogleFonts.roboto(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          _infoChip(Icons.badge_outlined,
                              _student.studentId),
                          const SizedBox(width: 8),
                          _infoChip(
                              Icons.class_, 'Class ${_student.classDiv}'),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),

          // ── Month picker ────────────────────────────────────
          SliverToBoxAdapter(
            child: Container(
              color: Colors.white,
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.chevron_left),
                    onPressed: () {
                      setState(() {
                        if (_selectedMonth == 1) {
                          _selectedMonth = 12;
                          _selectedYear--;
                        } else {
                          _selectedMonth--;
                        }
                      });
                      _load();
                    },
                  ),
                  Expanded(
                    child: Center(
                      child: Text(
                        DateFormat('MMMM yyyy').format(
                            DateTime(_selectedYear, _selectedMonth)),
                        style: GoogleFonts.roboto(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: AppTheme.primary,
                        ),
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.chevron_right),
                    onPressed: _selectedYear == _now.year &&
                            _selectedMonth == _now.month
                        ? null
                        : () {
                            setState(() {
                              if (_selectedMonth == 12) {
                                _selectedMonth = 1;
                                _selectedYear++;
                              } else {
                                _selectedMonth++;
                              }
                            });
                            _load();
                          },
                  ),
                ],
              ),
            ),
          ),

          // ── Monthly Summary Card ─────────────────────────────
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: StatCard(
                              label: 'Present',
                              value: '${_summary['present'] ?? 0}',
                              color: AppTheme.presentColor,
                              icon: Icons.check_circle,
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: StatCard(
                              label: 'Absent',
                              value: '${_summary['absent'] ?? 0}',
                              color: AppTheme.absentColor,
                              icon: Icons.cancel,
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: StatCard(
                              label: 'Total',
                              value: '${_summary['total'] ?? 0}',
                              color: AppTheme.gold,
                              icon: Icons.calendar_month,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      Row(
                        children: [
                          Expanded(
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: LinearProgressIndicator(
                                value: _attendancePct / 100,
                                backgroundColor:
                                    AppTheme.absentColor.withOpacity(0.15),
                                valueColor:
                                    const AlwaysStoppedAnimation(
                                        AppTheme.presentColor),
                                minHeight: 12,
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Text(
                            '${_attendancePct.toStringAsFixed(1)}%',
                            style: GoogleFonts.roboto(
                              fontSize: 14,
                              fontWeight: FontWeight.w800,
                              color: _attendancePct >= 75
                                  ? AppTheme.presentColor
                                  : AppTheme.absentColor,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Row(
                        children: [
                          Icon(
                            _attendancePct >= 75
                                ? Icons.thumb_up_outlined
                                : Icons.warning_amber_outlined,
                            size: 13,
                            color: _attendancePct >= 75
                                ? AppTheme.presentColor
                                : AppTheme.absentColor,
                          ),
                          const SizedBox(width: 6),
                          Text(
                            _attendancePct >= 75
                                ? 'Good attendance — keep it up!'
                                : 'Attendance below 75% — needs improvement',
                            style: GoogleFonts.roboto(
                              fontSize: 11,
                              color: _attendancePct >= 75
                                  ? AppTheme.presentColor
                                  : AppTheme.absentColor,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),

          // ── Daily Records ────────────────────────────────────
          const SliverToBoxAdapter(
            child: SectionTitle(title: 'Daily Records'),
          ),

          _filteredRecords.isEmpty
              ? SliverToBoxAdapter(
                  child: Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Text(
                        'No attendance marked for this month',
                        style: GoogleFonts.roboto(
                            color: AppTheme.textSecondary),
                      ),
                    ),
                  ),
                )
              : SliverList(
                  delegate: SliverChildBuilderDelegate(
                    (ctx, i) {
                      final r = _filteredRecords[i];
                      final date = DateTime.parse(r.date);
                      return Card(
                        margin:
                            const EdgeInsets.fromLTRB(16, 0, 16, 6),
                        child: ListTile(
                          dense: true,
                          leading: Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              color: r.isPresent
                                  ? AppTheme.presentColor.withOpacity(0.1)
                                  : AppTheme.absentColor.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Center(
                              child: Text(
                                DateFormat('dd').format(date),
                                style: GoogleFonts.roboto(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w800,
                                  color: r.isPresent
                                      ? AppTheme.presentColor
                                      : AppTheme.absentColor,
                                ),
                              ),
                            ),
                          ),
                          title: Text(
                            DateFormat('EEEE').format(date),
                            style: GoogleFonts.roboto(
                                fontWeight: FontWeight.w600,
                                fontSize: 13),
                          ),
                          subtitle: Text(
                            DateFormat('dd MMMM yyyy').format(date),
                            style: GoogleFonts.roboto(
                                fontSize: 11,
                                color: AppTheme.textSecondary),
                          ),
                          trailing: AttendanceBadge(
                              isPresent: r.isPresent),
                        ),
                      );
                    },
                    childCount: _filteredRecords.length,
                  ),
                ),

          const SliverToBoxAdapter(child: SizedBox(height: 30)),
        ],
      ),
    );
  }

  Widget _infoChip(IconData icon, String label) {
    return Container(
      padding:
          const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12, color: AppTheme.goldLight),
          const SizedBox(width: 4),
          Text(label,
              style: GoogleFonts.roboto(
                  fontSize: 11,
                  color: Colors.white,
                  fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }
}
