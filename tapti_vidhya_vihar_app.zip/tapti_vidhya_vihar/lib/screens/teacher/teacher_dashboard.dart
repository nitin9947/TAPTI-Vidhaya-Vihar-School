import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import '../../services/auth_service.dart';
import '../../services/database_service.dart';
import '../../utils/app_theme.dart';
import '../../widgets/common_widgets.dart';
import '../login_screen.dart';
import 'add_student_screen.dart';
import 'student_list_screen.dart';
import 'attendance_screen.dart';

class TeacherDashboard extends StatefulWidget {
  const TeacherDashboard({super.key});

  @override
  State<TeacherDashboard> createState() => _TeacherDashboardState();
}

class _TeacherDashboardState extends State<TeacherDashboard> {
  int _studentCount = 0;
  int _presentToday = 0;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  void _refresh() {
    final teacher = AuthService.currentUser?.teacher;
    if (teacher == null) return;
    final classDiv = teacher.assignedClass;
    final today = DateFormat('yyyy-MM-dd').format(DateTime.now());
    int count = 0;
    int present = 0;
    if (classDiv != null) {
      final students = DatabaseService.getStudentsByClass(classDiv);
      count = students.length;
      for (final s in students) {
        final rec = DatabaseService.getAttendance(s.studentId, today);
        if (rec != null && rec.isPresent) present++;
      }
    }
    setState(() {
      _studentCount = count;
      _presentToday = present;
    });
  }

  @override
  Widget build(BuildContext context) {
    final teacher = AuthService.currentUser!.teacher!;

    return Scaffold(
      backgroundColor: AppTheme.background,
      body: RefreshIndicator(
        color: AppTheme.primary,
        onRefresh: () async => _refresh(),
        child: CustomScrollView(
          slivers: [
            SliverAppBar(
              expandedHeight: 170,
              pinned: true,
              backgroundColor: AppTheme.primary,
              automaticallyImplyLeading: false,
              actions: [
                IconButton(
                  icon: const Icon(Icons.logout, color: Colors.white),
                  onPressed: () {
                    AuthService.logout();
                    Navigator.pushReplacement(context,
                        MaterialPageRoute(
                            builder: (_) => const LoginScreen()));
                  },
                ),
              ],
              flexibleSpace: FlexibleSpaceBar(
                background: Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [AppTheme.primaryDark, AppTheme.primary],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                  child: SafeArea(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(3),
                            decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.white),
                            child: ClipOval(
                              child: Image.asset(
                                'assets/images/school_logo.png',
                                width: 52,
                                height: 52,
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          const SizedBox(width: 14),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Teacher',
                                style: GoogleFonts.roboto(
                                    color: AppTheme.goldLight,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w500),
                              ),
                              Text(
                                teacher.name,
                                style: GoogleFonts.roboto(
                                    color: Colors.white,
                                    fontSize: 20,
                                    fontWeight: FontWeight.w800),
                              ),
                              if (teacher.assignedClass != null)
                                Row(
                                  children: [
                                    const Icon(Icons.class_,
                                        color: Colors.white60, size: 13),
                                    const SizedBox(width: 4),
                                    Text(
                                      'Class ${teacher.assignedClass}',
                                      style: GoogleFonts.roboto(
                                          color: Colors.white70,
                                          fontSize: 12),
                                    ),
                                  ],
                                ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),

            // Stats
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Expanded(
                      child: StatCard(
                        label: 'My Students',
                        value: '$_studentCount',
                        color: AppTheme.primary,
                        icon: Icons.school,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: StatCard(
                        label: 'Present Today',
                        value: '$_presentToday',
                        color: AppTheme.presentColor,
                        icon: Icons.check_circle_outline,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: StatCard(
                        label: 'Absent Today',
                        value:
                            '${_studentCount - _presentToday}',
                        color: AppTheme.absentColor,
                        icon: Icons.cancel_outlined,
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // Today's date
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(
                    color: AppTheme.gold.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                        color: AppTheme.gold.withOpacity(0.3)),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.calendar_today,
                          color: AppTheme.goldDark, size: 16),
                      const SizedBox(width: 8),
                      Text(
                        DateFormat('EEEE, dd MMMM yyyy')
                            .format(DateTime.now()),
                        style: GoogleFonts.roboto(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color: AppTheme.goldDark,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),

            const SliverToBoxAdapter(
                child: SectionTitle(title: 'Actions')),

            // Action Grid
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 80),
              sliver: SliverGrid(
                gridDelegate:
                    const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 1.1,
                ),
                delegate: SliverChildListDelegate([
                  DashboardCard(
                    icon: Icons.person_add_alt_1,
                    title: 'Add Student',
                    subtitle: 'Enroll new student',
                    color: AppTheme.primary,
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => const AddStudentScreen()),
                    ).then((_) => _refresh()),
                  ),
                  DashboardCard(
                    icon: Icons.people_alt,
                    title: 'My Students',
                    subtitle: 'View student list',
                    color: const Color(0xFF5C6BC0),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => const StudentListScreen()),
                    ).then((_) => _refresh()),
                  ),
                  DashboardCard(
                    icon: Icons.fact_check_outlined,
                    title: 'Mark Attendance',
                    subtitle: 'Today\'s attendance',
                    color: AppTheme.presentColor,
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => const AttendanceScreen()),
                    ).then((_) => _refresh()),
                  ),
                  DashboardCard(
                    icon: Icons.bar_chart,
                    title: 'Attendance Report',
                    subtitle: 'Monthly summary',
                    color: AppTheme.gold,
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => const AttendanceScreen(
                              viewMode: true)),
                    ),
                  ),
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
