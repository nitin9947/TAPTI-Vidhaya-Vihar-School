import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../services/auth_service.dart';
import '../../services/database_service.dart';
import '../../utils/app_theme.dart';
import '../../widgets/common_widgets.dart';
import '../login_screen.dart';
import 'class_management_screen.dart';
import 'teacher_management_screen.dart';
import 'admin_student_list_screen.dart';
import 'admin_attendance_screen.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  int _teacherCount = 0;
  int _studentCount = 0;
  int _classCount = 0;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  void _refresh() {
    setState(() {
      _teacherCount = DatabaseService.getTeachers().length;
      _studentCount = DatabaseService.getStudents().length;
      _classCount = DatabaseService.getClasses().length;
    });
  }

  void _logout() {
    AuthService.logout();
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (_) => const LoginScreen()));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      body: RefreshIndicator(
        color: AppTheme.primary,
        onRefresh: () async => _refresh(),
        child: CustomScrollView(
          slivers: [
            // ── App Bar ─────────────────────────────────────────
            SliverAppBar(
              expandedHeight: 170,
              pinned: true,
              backgroundColor: AppTheme.primary,
              actions: [
                IconButton(
                  icon: const Icon(Icons.refresh, color: Colors.white),
                  onPressed: _refresh,
                ),
                IconButton(
                  icon: const Icon(Icons.logout, color: Colors.white),
                  onPressed: _logout,
                ),
              ],
              flexibleSpace: FlexibleSpaceBar(
                background: Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [AppTheme.primaryDark, AppTheme.primary],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                  child: SafeArea(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(4),
                            decoration: const BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.white,
                            ),
                            child: ClipOval(
                              child: Image.asset(
                                'assets/images/school_logo.png',
                                width: 56,
                                height: 56,
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          const SizedBox(width: 14),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Super Admin',
                                style: GoogleFonts.roboto(
                                    color: AppTheme.goldLight,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w500),
                              ),
                              Text(
                                'Nitin',
                                style: GoogleFonts.roboto(
                                    color: Colors.white,
                                    fontSize: 22,
                                    fontWeight: FontWeight.w800),
                              ),
                              Text(
                                'Tapti Vidhya Vihar',
                                style: GoogleFonts.roboto(
                                    color: Colors.white70, fontSize: 12),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),

            // ── Stats Row ───────────────────────────────────────
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Expanded(
                        child: StatCard(
                            label: 'Classes',
                            value: '$_classCount',
                            color: AppTheme.gold,
                            icon: Icons.class_)),
                    const SizedBox(width: 10),
                    Expanded(
                        child: StatCard(
                            label: 'Teachers',
                            value: '$_teacherCount',
                            color: AppTheme.primary,
                            icon: Icons.people)),
                    const SizedBox(width: 10),
                    Expanded(
                        child: StatCard(
                            label: 'Students',
                            value: '$_studentCount',
                            color: AppTheme.presentColor,
                            icon: Icons.school)),
                  ],
                ),
              ),
            ),

            // ── Quick Actions Grid ──────────────────────────────
            const SliverToBoxAdapter(
              child: SectionTitle(title: 'Quick Actions'),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              sliver: SliverGrid(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 1.1,
                ),
                delegate: SliverChildListDelegate([
                  DashboardCard(
                    icon: Icons.class_,
                    title: 'Manage Classes',
                    subtitle: 'Create & edit classes',
                    color: AppTheme.gold,
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => const ClassManagementScreen()),
                    ).then((_) => _refresh()),
                  ),
                  DashboardCard(
                    icon: Icons.supervisor_account,
                    title: 'Manage Teachers',
                    subtitle: 'Add & remove teachers',
                    color: AppTheme.primary,
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => const TeacherManagementScreen()),
                    ).then((_) => _refresh()),
                  ),
                  DashboardCard(
                    icon: Icons.people_alt,
                    title: 'All Students',
                    subtitle: 'View student records',
                    color: AppTheme.presentColor,
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => const AdminStudentListScreen()),
                    ).then((_) => _refresh()),
                  ),
                  DashboardCard(
                    icon: Icons.fact_check,
                    title: 'Attendance',
                    subtitle: 'View all records',
                    color: const Color(0xFF5C6BC0),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => const AdminAttendanceScreen()),
                    ),
                  ),
                ]),
              ),
            ),

            // ── Recent Teachers ─────────────────────────────────
            const SliverToBoxAdapter(
                child: SectionTitle(title: 'Teachers')),
            SliverToBoxAdapter(
              child: _buildTeacherList(),
            ),

            const SliverToBoxAdapter(child: SizedBox(height: 30)),
          ],
        ),
      ),
    );
  }

  Widget _buildTeacherList() {
    final teachers = DatabaseService.getTeachers();
    if (teachers.isEmpty) {
      return Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
              color: AppTheme.divider, style: BorderStyle.solid),
        ),
        child: Center(
          child: Column(
            children: [
              Icon(Icons.people_outline,
                  color: AppTheme.textSecondary.withOpacity(0.4), size: 36),
              const SizedBox(height: 8),
              Text(
                'No teachers added yet',
                style: GoogleFonts.roboto(
                    color: AppTheme.textSecondary, fontSize: 13),
              ),
            ],
          ),
        ),
      );
    }
    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      padding: const EdgeInsets.symmetric(horizontal: 16),
      itemCount: teachers.length,
      itemBuilder: (ctx, i) {
        final t = teachers[i];
        return Card(
          margin: const EdgeInsets.only(bottom: 8),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: AppTheme.primary.withOpacity(0.1),
              child: Text(
                t.name[0].toUpperCase(),
                style: GoogleFonts.roboto(
                    color: AppTheme.primary, fontWeight: FontWeight.w700),
              ),
            ),
            title: Text(t.name,
                style: GoogleFonts.roboto(fontWeight: FontWeight.w600)),
            subtitle: Text('@${t.username}',
                style: GoogleFonts.roboto(
                    fontSize: 12, color: AppTheme.textSecondary)),
            trailing: t.assignedClass != null
                ? ClassChip(label: t.assignedClass!)
                : null,
          ),
        );
      },
    );
  }
}
