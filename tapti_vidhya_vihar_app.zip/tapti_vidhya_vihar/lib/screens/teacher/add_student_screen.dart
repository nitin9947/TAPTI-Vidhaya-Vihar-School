import 'dart:io';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import '../../models/models.dart';
import '../../services/auth_service.dart';
import '../../services/database_service.dart';
import '../../utils/app_theme.dart';

class AddStudentScreen extends StatefulWidget {
  final Student? editing;
  const AddStudentScreen({super.key, this.editing});

  @override
  State<AddStudentScreen> createState() => _AddStudentScreenState();
}

class _AddStudentScreenState extends State<AddStudentScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  String? _selectedClassDiv;
  String? _photoPath;
  bool _saving = false;
  final _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    if (widget.editing != null) {
      _nameCtrl.text = widget.editing!.name;
      _selectedClassDiv = widget.editing!.classDiv;
      _photoPath = widget.editing!.photoPath;
    } else {
      // Pre-select teacher's assigned class
      final teacher = AuthService.currentUser?.teacher;
      if (teacher?.assignedClass != null) {
        _selectedClassDiv = teacher!.assignedClass;
      }
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final picked = await _picker.pickImage(
        source: source,
        maxWidth: 600,
        maxHeight: 600,
        imageQuality: 80,
      );
      if (picked == null) return;
      final appDir = await getApplicationDocumentsDirectory();
      final fileName = '${DateTime.now().millisecondsSinceEpoch}.jpg';
      final saved = await File(picked.path)
          .copy(p.join(appDir.path, 'student_photos', fileName));
      // Ensure directory exists
      await Directory(p.join(appDir.path, 'student_photos'))
          .create(recursive: true);
      await File(picked.path)
          .copy(p.join(appDir.path, 'student_photos', fileName));
      setState(() => _photoPath = saved.path);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error picking image: $e')));
    }
  }

  void _showImageSource() {
    showModalBottomSheet(
      context: context,
      builder: (_) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt, color: AppTheme.primary),
              title: const Text('Take Photo'),
              onTap: () {
                Navigator.pop(context);
                _pickImage(ImageSource.camera);
              },
            ),
            ListTile(
              leading:
                  const Icon(Icons.photo_library, color: AppTheme.primary),
              title: const Text('Choose from Gallery'),
              onTap: () {
                Navigator.pop(context);
                _pickImage(ImageSource.gallery);
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedClassDiv == null) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please select a class')));
      return;
    }

    setState(() => _saving = true);

    // Parse class and division
    final classMatch =
        RegExp(r'^(\d+)([A-Z]+)$').firstMatch(_selectedClassDiv!);
    if (classMatch == null) {
      setState(() => _saving = false);
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Invalid class format')));
      return;
    }
    final className = classMatch.group(1)!;
    final division = classMatch.group(2)!;

    final teacherId =
        AuthService.currentUser?.id ?? 'admin';

    if (widget.editing != null) {
      // Update
      widget.editing!.name = _nameCtrl.text.trim();
      widget.editing!.className = className;
      widget.editing!.division = division;
      widget.editing!.photoPath = _photoPath;
      await widget.editing!.save();
    } else {
      // Generate unique ID
      final studentId =
          DatabaseService.generateStudentId(className, division);
      final student = Student(
        studentId: studentId,
        name: _nameCtrl.text.trim(),
        className: className,
        division: division,
        photoPath: _photoPath,
        addedByTeacherId: teacherId,
      );
      await DatabaseService.saveStudent(student);
    }

    setState(() => _saving = false);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(widget.editing != null
            ? 'Student updated successfully'
            : 'Student added successfully'),
        backgroundColor: AppTheme.presentColor,
      ));
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    final classDivs = DatabaseService.getAllClassDivisions();
    final teacher = AuthService.currentUser?.teacher;

    // If teacher has assigned class, restrict to that class only
    final availableClasses = teacher?.assignedClass != null
        ? classDivs
            .where((c) => c == teacher!.assignedClass)
            .toList()
        : classDivs;

    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        title: Text(widget.editing == null
            ? 'Add New Student'
            : 'Edit Student'),
        backgroundColor: AppTheme.primary,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Photo Section
              Center(
                child: Column(
                  children: [
                    GestureDetector(
                      onTap: _showImageSource,
                      child: Container(
                        width: 120,
                        height: 120,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: AppTheme.primary.withOpacity(0.08),
                          border: Border.all(
                              color: AppTheme.primary.withOpacity(0.3),
                              width: 2),
                          image: _photoPath != null &&
                                  File(_photoPath!).existsSync()
                              ? DecorationImage(
                                  image: FileImage(File(_photoPath!)),
                                  fit: BoxFit.cover,
                                )
                              : null,
                        ),
                        child: _photoPath == null ||
                                !File(_photoPath!).existsSync()
                            ? Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.center,
                                children: [
                                  const Icon(Icons.add_a_photo,
                                      color: AppTheme.primary, size: 32),
                                  const SizedBox(height: 4),
                                  Text(
                                    'Add Photo',
                                    style: GoogleFonts.roboto(
                                      fontSize: 11,
                                      color: AppTheme.primary,
                                    ),
                                  ),
                                ],
                              )
                            : null,
                      ),
                    ),
                    const SizedBox(height: 8),
                    TextButton.icon(
                      onPressed: _showImageSource,
                      icon: const Icon(Icons.camera_alt, size: 16),
                      label: Text(_photoPath == null
                          ? 'Upload Photo'
                          : 'Change Photo'),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // Student Name
              TextFormField(
                controller: _nameCtrl,
                textCapitalization: TextCapitalization.words,
                decoration: const InputDecoration(
                  labelText: 'Student Full Name',
                  prefixIcon:
                      Icon(Icons.person_outline, color: AppTheme.primary),
                ),
                validator: (v) =>
                    v == null || v.trim().isEmpty ? 'Name is required' : null,
              ),

              const SizedBox(height: 16),

              // Class Dropdown
              if (availableClasses.isEmpty)
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AppTheme.gold.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                        color: AppTheme.gold.withOpacity(0.3)),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.info_outline,
                          color: AppTheme.goldDark, size: 18),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          'No classes available. Ask the admin to create classes first.',
                          style: GoogleFonts.roboto(
                              fontSize: 13, color: AppTheme.goldDark),
                        ),
                      ),
                    ],
                  ),
                )
              else
                DropdownButtonFormField<String>(
                  value: _selectedClassDiv,
                  decoration: const InputDecoration(
                    labelText: 'Select Class & Division',
                    prefixIcon:
                        Icon(Icons.class_, color: AppTheme.primary),
                  ),
                  items: availableClasses
                      .map((cd) => DropdownMenuItem(
                          value: cd,
                          child: Text('Class $cd')))
                      .toList(),
                  onChanged: (v) =>
                      setState(() => _selectedClassDiv = v),
                  validator: (v) =>
                      v == null ? 'Please select a class' : null,
                ),

              const SizedBox(height: 32),

              SizedBox(
                height: 52,
                child: ElevatedButton.icon(
                  onPressed: _saving ? null : _save,
                  icon: _saving
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                              color: Colors.white, strokeWidth: 2),
                        )
                      : const Icon(Icons.save_outlined),
                  label: Text(widget.editing == null
                      ? 'Add Student'
                      : 'Save Changes'),
                  style: ElevatedButton.styleFrom(
                      textStyle: GoogleFonts.roboto(
                          fontSize: 16, fontWeight: FontWeight.w700)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
