import 'package:hive_flutter/hive_flutter.dart';
import '../models/models.dart';

class DatabaseService {
  static const String _classBox = 'classes';
  static const String _teacherBox = 'teachers';
  static const String _studentBox = 'students';
  static const String _attendanceBox = 'attendance';

  static Future<void> init() async {
    await Hive.initFlutter();
    Hive.registerAdapter(SchoolClassAdapter());
    Hive.registerAdapter(TeacherAdapter());
    Hive.registerAdapter(StudentAdapter());
    Hive.registerAdapter(AttendanceRecordAdapter());
    await Hive.openBox<SchoolClass>(_classBox);
    await Hive.openBox<Teacher>(_teacherBox);
    await Hive.openBox<Student>(_studentBox);
    await Hive.openBox<AttendanceRecord>(_attendanceBox);
  }

  // ── Classes ──────────────────────────────────────────────────
  static Box<SchoolClass> get classBox => Hive.box<SchoolClass>(_classBox);
  static Box<Teacher> get teacherBox => Hive.box<Teacher>(_teacherBox);
  static Box<Student> get studentBox => Hive.box<Student>(_studentBox);
  static Box<AttendanceRecord> get attendanceBox =>
      Hive.box<AttendanceRecord>(_attendanceBox);

  // ── School Class CRUD ────────────────────────────────────────
  static Future<void> saveClass(SchoolClass sc) async {
    await classBox.put(sc.classId, sc);
  }

  static List<SchoolClass> getClasses() => classBox.values.toList();

  static Future<void> deleteClass(String classId) async {
    await classBox.delete(classId);
  }

  static SchoolClass? getClassById(String classId) => classBox.get(classId);

  static Future<void> addDivisionToClass(
      String classId, String division) async {
    final sc = classBox.get(classId);
    if (sc != null && !sc.divisions.contains(division)) {
      sc.divisions.add(division);
      await sc.save();
    }
  }

  static Future<void> removeDivisionFromClass(
      String classId, String division) async {
    final sc = classBox.get(classId);
    if (sc != null) {
      sc.divisions.remove(division);
      await sc.save();
    }
  }

  /// Returns all class-division combos e.g. ["10A","10B","9A"]
  static List<String> getAllClassDivisions() {
    final List<String> result = [];
    for (final sc in classBox.values) {
      for (final d in sc.divisions) {
        result.add('${sc.className}$d');
      }
    }
    result.sort();
    return result;
  }

  // ── Teacher CRUD ──────────────────────────────────────────────
  static Future<void> saveTeacher(Teacher t) async {
    await teacherBox.put(t.teacherId, t);
  }

  static List<Teacher> getTeachers() => teacherBox.values.toList();

  static Future<void> deleteTeacher(String teacherId) async {
    await teacherBox.delete(teacherId);
  }

  static Teacher? getTeacherByUsername(String username) {
    try {
      return teacherBox.values
          .firstWhere((t) => t.username == username);
    } catch (_) {
      return null;
    }
  }

  static Teacher? getTeacherById(String id) => teacherBox.get(id);

  // ── Student CRUD ──────────────────────────────────────────────
  static Future<void> saveStudent(Student s) async {
    await studentBox.put(s.studentId, s);
  }

  static List<Student> getStudents() => studentBox.values.toList();

  static List<Student> getStudentsByClass(String classDiv) {
    return studentBox.values
        .where((s) => s.classDiv == classDiv)
        .toList()
      ..sort((a, b) => a.name.compareTo(b.name));
  }

  static Future<void> deleteStudent(String studentId) async {
    await studentBox.delete(studentId);
  }

  static Student? getStudentById(String id) => studentBox.get(id);

  static bool studentIdExists(String id) => studentBox.containsKey(id);

  static String generateStudentId(String className, String division) {
    final prefix = '$className$division';
    int counter = 101;
    while (studentIdExists('$prefix$counter')) {
      counter++;
    }
    return '$prefix$counter';
  }

  // ── Attendance ────────────────────────────────────────────────
  static Future<void> saveAttendance(AttendanceRecord rec) async {
    await attendanceBox.put(rec.recordId, rec);
  }

  static AttendanceRecord? getAttendance(String studentId, String date) {
    try {
      return attendanceBox.values
          .firstWhere((r) => r.studentId == studentId && r.date == date);
    } catch (_) {
      return null;
    }
  }

  static List<AttendanceRecord> getAttendanceForStudent(String studentId) {
    return attendanceBox.values
        .where((r) => r.studentId == studentId)
        .toList()
      ..sort((a, b) => b.date.compareTo(a.date));
  }

  static List<AttendanceRecord> getAttendanceForDate(
      String classDiv, String date) {
    final students = getStudentsByClass(classDiv).map((s) => s.studentId).toSet();
    return attendanceBox.values
        .where((r) => students.contains(r.studentId) && r.date == date)
        .toList();
  }

  static Map<String, bool?> getAttendanceMapForDate(
      String classDiv, String date) {
    final students = getStudentsByClass(classDiv);
    final Map<String, bool?> map = {};
    for (final s in students) {
      final rec = getAttendance(s.studentId, date);
      map[s.studentId] = rec?.isPresent;
    }
    return map;
  }

  /// Returns {present: x, absent: y, total: z} for a student in a month
  static Map<String, int> getMonthlyAttendanceSummary(
      String studentId, int year, int month) {
    final monthStr =
        '$year-${month.toString().padLeft(2, '0')}';
    final records = attendanceBox.values
        .where((r) => r.studentId == studentId && r.date.startsWith(monthStr))
        .toList();
    final present = records.where((r) => r.isPresent).length;
    final absent = records.where((r) => !r.isPresent).length;
    return {'present': present, 'absent': absent, 'total': records.length};
  }

  static Future<void> deleteAttendanceForStudent(String studentId) async {
    final keys = attendanceBox.values
        .where((r) => r.studentId == studentId)
        .map((r) => r.recordId)
        .toList();
    await attendanceBox.deleteAll(keys);
  }
}
