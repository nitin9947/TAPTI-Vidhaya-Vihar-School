import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:uuid/uuid.dart';
import '../../models/models.dart';
import '../../services/database_service.dart';
import '../../utils/app_theme.dart';
import '../../widgets/common_widgets.dart';

class TeacherManagementScreen extends StatefulWidget {
  const TeacherManagementScreen({super.key});

  @override
  State<TeacherManagementScreen> createState() =>
      _TeacherManagementScreenState();
}

class _TeacherManagementScreenState extends State<TeacherManagementScreen> {
  List<Teacher> _teachers = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() => setState(
      () => _teachers = DatabaseService.getTeachers()
        ..sort((a, b) => a.name.compareTo(b.name)));

  void _showAddTeacherSheet({Teacher? editing}) {
    final nameCtrl =
        TextEditingController(text: editing?.name ?? '');
    final userCtrl =
        TextEditingController(text: editing?.username ?? '');
    final passCtrl = TextEditingController();
    String? selectedClass = editing?.assignedClass;
    final classDivs = DatabaseService.getAllClassDivisions();
    final formKey = GlobalKey<FormState>();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(builder: (ctx, setSheet) {
        return Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius:
                BorderRadius.vertical(top: Radius.circular(24)),
          ),
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 24,
            top: 24,
            left: 24,
            right: 24,
          ),
          child: Form(
            key: formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  editing == null ? 'Add New Teacher' : 'Edit Teacher',
                  style: GoogleFonts.roboto(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.primary,
                  ),
                ),
                const SizedBox(height: 20),
                TextFormField(
                  controller: nameCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Full Name',
                    prefixIcon: Icon(Icons.person_outline,
                        color: AppTheme.primary),
                  ),
                  validator: (v) =>
                      v == null || v.trim().isEmpty ? 'Required' : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: userCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Username',
                    prefixIcon: Icon(Icons.alternate_email,
                        color: AppTheme.primary),
                  ),
                  validator: (v) =>
                      v == null || v.trim().isEmpty ? 'Required' : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: passCtrl,
                  obscureText: true,
                  decoration: InputDecoration(
                    labelText: editing == null
                        ? 'Password'
                        : 'New Password (leave blank to keep)',
                    prefixIcon: const Icon(Icons.lock_outline,
                        color: AppTheme.primary),
                  ),
                  validator: editing == null
                      ? (v) => v == null || v.trim().isEmpty
                          ? 'Required'
                          : null
                      : null,
                ),
                const SizedBox(height: 12),
                if (classDivs.isNotEmpty) ...[
                  DropdownButtonFormField<String>(
                    value: selectedClass,
                    decoration: const InputDecoration(
                      labelText: 'Assign Class (Optional)',
                      prefixIcon: Icon(Icons.class_,
                          color: AppTheme.primary),
                    ),
                    items: [
                      const DropdownMenuItem(
                          value: null, child: Text('No assignment')),
                      ...classDivs.map((cd) => DropdownMenuItem(
                          value: cd, child: Text(cd))),
                    ],
                    onChanged: (v) =>
                        setSheet(() => selectedClass = v),
                  ),
                  const SizedBox(height: 12),
                ],
                ElevatedButton(
                  onPressed: () async {
                    if (!formKey.currentState!.validate()) return;
                    // Check username uniqueness
                    final existing =
                        DatabaseService.getTeacherByUsername(
                            userCtrl.text.trim().toLowerCase());
                    if (existing != null &&
                        existing.teacherId != editing?.teacherId) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                            content: Text('Username already taken')),
                      );
                      return;
                    }
                    if (editing == null) {
                      final t = Teacher(
                        teacherId: const Uuid().v4(),
                        name: nameCtrl.text.trim(),
                        username:
                            userCtrl.text.trim().toLowerCase(),
                        password: passCtrl.text.trim(),
                        assignedClass: selectedClass,
                      );
                      await DatabaseService.saveTeacher(t);
                    } else {
                      editing.name = nameCtrl.text.trim();
                      editing.username =
                          userCtrl.text.trim().toLowerCase();
                      if (passCtrl.text.trim().isNotEmpty) {
                        editing.password = passCtrl.text.trim();
                      }
                      editing.assignedClass = selectedClass;
                      await editing.save();
                    }
                    Navigator.pop(ctx);
                    _load();
                  },
                  child: Text(editing == null
                      ? 'Add Teacher'
                      : 'Save Changes'),
                ),
              ],
            ),
          ),
        );
      }),
    );
  }

  void _deleteTeacher(Teacher t) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Delete ${t.name}?',
            style: GoogleFonts.roboto(
                fontWeight: FontWeight.w700,
                color: AppTheme.absentColor)),
        content: const Text(
            'This teacher will no longer be able to log in.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.absentColor),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (confirm == true) {
      await DatabaseService.deleteTeacher(t.teacherId);
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        title: const Text('Teacher Management'),
        backgroundColor: AppTheme.primary,
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddTeacherSheet(),
        icon: const Icon(Icons.person_add),
        label: const Text('Add Teacher'),
        backgroundColor: AppTheme.primary,
      ),
      body: _teachers.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.people_outline,
                      size: 64,
                      color: AppTheme.primary.withOpacity(0.3)),
                  const SizedBox(height: 16),
                  Text(
                    'No teachers added yet',
                    style: GoogleFonts.roboto(
                        color: AppTheme.textSecondary, fontSize: 16),
                  ),
                ],
              ),
            )
          : ListView.builder(
              padding:
                  const EdgeInsets.fromLTRB(16, 16, 16, 80),
              itemCount: _teachers.length,
              itemBuilder: (ctx, i) {
                final t = _teachers[i];
                return Card(
                  margin: const EdgeInsets.only(bottom: 10),
                  child: ListTile(
                    leading: CircleAvatar(
                      radius: 24,
                      backgroundColor:
                          AppTheme.primary.withOpacity(0.1),
                      child: Text(
                        t.name[0].toUpperCase(),
                        style: GoogleFonts.roboto(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                          color: AppTheme.primary,
                        ),
                      ),
                    ),
                    title: Text(t.name,
                        style: GoogleFonts.roboto(
                            fontWeight: FontWeight.w600)),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('@${t.username}',
                            style: GoogleFonts.roboto(
                                fontSize: 12,
                                color: AppTheme.textSecondary)),
                        if (t.assignedClass != null)
                          ClassChip(label: t.assignedClass!),
                      ],
                    ),
                    isThreeLine: t.assignedClass != null,
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.edit_outlined,
                              color: AppTheme.primary, size: 20),
                          onPressed: () =>
                              _showAddTeacherSheet(editing: t),
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete_outline,
                              color: AppTheme.absentColor, size: 20),
                          onPressed: () => _deleteTeacher(t),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}
