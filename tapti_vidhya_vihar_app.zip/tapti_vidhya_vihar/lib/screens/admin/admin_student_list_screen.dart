// admin_student_list_screen.dart
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../models/models.dart';
import '../../services/database_service.dart';
import '../../utils/app_theme.dart';
import '../../widgets/common_widgets.dart';
import '../teacher/student_detail_screen.dart';

class AdminStudentListScreen extends StatefulWidget {
  const AdminStudentListScreen({super.key});

  @override
  State<AdminStudentListScreen> createState() =>
      _AdminStudentListScreenState();
}

class _AdminStudentListScreenState extends State<AdminStudentListScreen> {
  List<Student> _students = [];
  List<Student> _filtered = [];
  String _search = '';
  String? _filterClass;

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() {
    final all = DatabaseService.getStudents()
      ..sort((a, b) => a.name.compareTo(b.name));
    setState(() {
      _students = all;
      _applyFilter();
    });
  }

  void _applyFilter() {
    setState(() {
      _filtered = _students.where((s) {
        final matchSearch = _search.isEmpty ||
            s.name.toLowerCase().contains(_search.toLowerCase()) ||
            s.studentId.toLowerCase().contains(_search.toLowerCase());
        final matchClass =
            _filterClass == null || s.classDiv == _filterClass;
        return matchSearch && matchClass;
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    final classDivs = DatabaseService.getAllClassDivisions();

    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        title: Text('All Students (${_students.length})'),
        backgroundColor: AppTheme.primary,
      ),
      body: Column(
        children: [
          // Search + filter
          Container(
            color: AppTheme.primary.withOpacity(0.05),
            padding: const EdgeInsets.all(12),
            child: Column(
              children: [
                TextField(
                  onChanged: (v) {
                    _search = v;
                    _applyFilter();
                  },
                  decoration: const InputDecoration(
                    hintText: 'Search by name or ID...',
                    prefixIcon: Icon(Icons.search),
                    contentPadding: EdgeInsets.symmetric(
                        horizontal: 16, vertical: 10),
                  ),
                ),
                if (classDivs.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        ClassChip(
                          label: 'All',
                          selected: _filterClass == null,
                          onTap: () {
                            _filterClass = null;
                            _applyFilter();
                          },
                        ),
                        const SizedBox(width: 6),
                        ...classDivs.map((cd) => Padding(
                              padding: const EdgeInsets.only(right: 6),
                              child: ClassChip(
                                label: cd,
                                selected: _filterClass == cd,
                                onTap: () {
                                  _filterClass = cd;
                                  _applyFilter();
                                },
                              ),
                            )),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
          Expanded(
            child: _filtered.isEmpty
                ? Center(
                    child: Text('No students found',
                        style: GoogleFonts.roboto(
                            color: AppTheme.textSecondary)))
                : ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: _filtered.length,
                    itemBuilder: (ctx, i) {
                      final s = _filtered[i];
                      return Card(
                        margin: const EdgeInsets.only(bottom: 8),
                        child: ListTile(
                          leading: StudentAvatar(
                              photoPath: s.photoPath,
                              name: s.name,
                              radius: 22),
                          title: Text(s.name,
                              style: GoogleFonts.roboto(
                                  fontWeight: FontWeight.w600)),
                          subtitle: Text(
                            'ID: ${s.studentId}',
                            style: GoogleFonts.roboto(
                                fontSize: 12,
                                color: AppTheme.textSecondary),
                          ),
                          trailing: ClassChip(label: s.classDiv),
                          onTap: () => Navigator.push(
                            ctx,
                            MaterialPageRoute(
                              builder: (_) =>
                                  StudentDetailScreen(student: s),
                            ),
                          ).then((_) => _load()),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
