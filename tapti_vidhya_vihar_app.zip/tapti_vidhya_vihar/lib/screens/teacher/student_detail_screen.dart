import 'dart:io';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import '../../models/models.dart';
import '../../services/database_service.dart';
import '../../utils/app_theme.dart';
import '../../widgets/common_widgets.dart';

class StudentDetailScreen extends StatefulWidget {
  final Student student;
  const StudentDetailScreen({super.key, required this.student});

  @override
  State<StudentDetailScreen> createState() => _StudentDetailScreenState();
}

class _StudentDetailScreenState extends State<StudentDetailScreen> {
  late Student _student;
  List<AttendanceRecord> _records = [];
  Map<String, int> _monthlySummary = {};
  final _now = DateTime.now();

  @override
  void initState() {
    super.initState();
    _student = widget.student;
    _load();
  }

  void _load() {
    final records =
        DatabaseService.getAttendanceForStudent(_student.studentId);
    final summary = DatabaseService.getMonthlyAttendanceSummary(
        _student.studentId, _now.year, _now.month);
    setState(() {
      _records = records.take(30).toList();
      _monthlySummary = summary;
    });
  }

  @override
  Widget build(BuildContext context) {
    final presentPct = _monthlySummary['total'] == 0
        ? 0.0
        : (_monthlySummary['present']! /
                _monthlySummary['total']!) *
            100;

    return Scaffold(
      backgroundColor: AppTheme.background,
      body: CustomScrollView(
        slivers: [
          // ── Header ──────────────────────────────────────────
          SliverAppBar(
            expandedHeight: 240,
            pinned: true,
            backgroundColor: AppTheme.primary,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [AppTheme.primaryDark, AppTheme.primary],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: SafeArea(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const SizedBox(height: 40),
                      // Photo
                      Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                              color: AppTheme.goldLight, width: 3),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.3),
                              blurRadius: 12,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: _student.photoPath != null &&
                                File(_student.photoPath!).existsSync()
                            ? CircleAvatar(
                                radius: 50,
                                backgroundImage: FileImage(
                                    File(_student.photoPath!)),
                              )
                            : CircleAvatar(
                                radius: 50,
                                backgroundColor:
                                    AppTheme.gold.withOpacity(0.2),
                                child: Text(
                                  _student.name[0].toUpperCase(),
                                  style: GoogleFonts.roboto(
                                    fontSize: 38,
                                    fontWeight: FontWeight.w800,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        _student.name,
                        style: GoogleFonts.roboto(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          _headerChip(
                              'ID: ${_student.studentId}',
                              Icons.badge_outlined),
                          const SizedBox(width: 8),
                          _headerChip(
                              'Class ${_student.classDiv}',
                              Icons.class_),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),

          // ── Monthly Summary ──────────────────────────────────
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    DateFormat('MMMM yyyy').format(_now),
                    style: GoogleFonts.roboto(
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      color: AppTheme.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 8),

                  // Attendance progress bar
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: StatCard(
                                  label: 'Present',
                                  value:
                                      '${_monthlySummary['present'] ?? 0}',
                                  color: AppTheme.presentColor,
                                  icon: Icons.check_circle,
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: StatCard(
                                  label: 'Absent',
                                  value:
                                      '${_monthlySummary['absent'] ?? 0}',
                                  color: AppTheme.absentColor,
                                  icon: Icons.cancel,
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: StatCard(
                                  label: 'Total Days',
                                  value:
                                      '${_monthlySummary['total'] ?? 0}',
                                  color: AppTheme.gold,
                                  icon: Icons.calendar_month,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 14),
                          Row(
                            children: [
                              Expanded(
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(6),
                                  child: LinearProgressIndicator(
                                    value: presentPct / 100,
                                    backgroundColor: AppTheme.absentColor
                                        .withOpacity(0.15),
                                    valueColor:
                                        const AlwaysStoppedAnimation(
                                            AppTheme.presentColor),
                                    minHeight: 10,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 10),
                              Text(
                                '${presentPct.toStringAsFixed(1)}%',
                                style: GoogleFonts.roboto(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w700,
                                  color: AppTheme.presentColor,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Align(
                            alignment: Alignment.centerLeft,
                            child: Text(
                              'Monthly attendance rate',
                              style: GoogleFonts.roboto(
                                  fontSize: 11,
                                  color: AppTheme.textSecondary),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 16),
                  const SectionTitle(title: 'Recent Attendance'),
                ],
              ),
            ),
          ),

          // ── Attendance Records ────────────────────────────────
          _records.isEmpty
              ? SliverToBoxAdapter(
                  child: Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Text(
                        'No attendance records yet',
                        style: GoogleFonts.roboto(
                            color: AppTheme.textSecondary),
                      ),
                    ),
                  ),
                )
              : SliverList(
                  delegate: SliverChildBuilderDelegate(
                    (ctx, i) {
                      final r = _records[i];
                      final date = DateTime.parse(r.date);
                      return Card(
                        margin: const EdgeInsets.fromLTRB(16, 0, 16, 6),
                        child: ListTile(
                          dense: true,
                          leading: Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              color: r.isPresent
                                  ? AppTheme.presentColor.withOpacity(0.1)
                                  : AppTheme.absentColor.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Icon(
                              r.isPresent
                                  ? Icons.check_circle
                                  : Icons.cancel,
                              color: r.isPresent
                                  ? AppTheme.presentColor
                                  : AppTheme.absentColor,
                              size: 20,
                            ),
                          ),
                          title: Text(
                            DateFormat('EEEE').format(date),
                            style: GoogleFonts.roboto(
                                fontWeight: FontWeight.w600,
                                fontSize: 13),
                          ),
                          subtitle: Text(
                            DateFormat('dd MMMM yyyy').format(date),
                            style: GoogleFonts.roboto(
                                fontSize: 11,
                                color: AppTheme.textSecondary),
                          ),
                          trailing: AttendanceBadge(
                              isPresent: r.isPresent),
                        ),
                      );
                    },
                    childCount: _records.length,
                  ),
                ),

          const SliverToBoxAdapter(child: SizedBox(height: 30)),
        ],
      ),
    );
  }

  Widget _headerChip(String label, IconData icon) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12, color: AppTheme.goldLight),
          const SizedBox(width: 4),
          Text(
            label,
            style: GoogleFonts.roboto(
                fontSize: 11,
                color: Colors.white,
                fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }
}
