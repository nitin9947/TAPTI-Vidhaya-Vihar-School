import 'package:hive/hive.dart';

part 'models.g.dart';

// ─── School Class ───────────────────────────────────────────────
@HiveType(typeId: 0)
class SchoolClass extends HiveObject {
  @HiveField(0)
  String classId;

  @HiveField(1)
  String className; // e.g. "10"

  @HiveField(2)
  List<String> divisions; // e.g. ["A","B","C"]

  SchoolClass({
    required this.classId,
    required this.className,
    required this.divisions,
  });

  List<String> get classDivisions =>
      divisions.map((d) => '$className$d').toList();
}

// ─── Teacher ────────────────────────────────────────────────────
@HiveType(typeId: 1)
class Teacher extends HiveObject {
  @HiveField(0)
  String teacherId;

  @HiveField(1)
  String name;

  @HiveField(2)
  String username;

  @HiveField(3)
  String password;

  @HiveField(4)
  String? assignedClass; // e.g. "10A"

  @HiveField(5)
  String? photoPath;

  Teacher({
    required this.teacherId,
    required this.name,
    required this.username,
    required this.password,
    this.assignedClass,
    this.photoPath,
  });
}

// ─── Student ────────────────────────────────────────────────────
@HiveType(typeId: 2)
class Student extends HiveObject {
  @HiveField(0)
  String studentId; // unique e.g. 10A101

  @HiveField(1)
  String name;

  @HiveField(2)
  String className; // e.g. "10"

  @HiveField(3)
  String division; // e.g. "A"

  @HiveField(4)
  String? photoPath;

  @HiveField(5)
  String addedByTeacherId;

  Student({
    required this.studentId,
    required this.name,
    required this.className,
    required this.division,
    this.photoPath,
    required this.addedByTeacherId,
  });

  String get classDiv => '$className$division';
}

// ─── Attendance ─────────────────────────────────────────────────
@HiveType(typeId: 3)
class AttendanceRecord extends HiveObject {
  @HiveField(0)
  String recordId;

  @HiveField(1)
  String studentId;

  @HiveField(2)
  String date; // yyyy-MM-dd

  @HiveField(3)
  bool isPresent;

  @HiveField(4)
  String markedByTeacherId;

  AttendanceRecord({
    required this.recordId,
    required this.studentId,
    required this.date,
    required this.isPresent,
    required this.markedByTeacherId,
  });
}
