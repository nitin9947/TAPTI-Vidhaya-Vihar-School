import '../models/models.dart';
import 'database_service.dart';

enum UserRole { superAdmin, teacher, student }

class AuthUser {
  final UserRole role;
  final String id;
  final String name;
  final Teacher? teacher;
  final Student? student;

  AuthUser({
    required this.role,
    required this.id,
    required this.name,
    this.teacher,
    this.student,
  });
}

class AuthService {
  static AuthUser? _currentUser;
  static AuthUser? get currentUser => _currentUser;
  static bool get isLoggedIn => _currentUser != null;

  static AuthUser? login(String usernameOrId, String password) {
    // Super Admin
    if (usernameOrId.trim().toLowerCase() == 'nitin' && password == '1234') {
      _currentUser = AuthUser(
        role: UserRole.superAdmin,
        id: 'nitin',
        name: 'Nitin (Super Admin)',
      );
      return _currentUser;
    }

    // Teacher login
    final teacher = DatabaseService.getTeacherByUsername(
        usernameOrId.trim().toLowerCase());
    if (teacher != null && teacher.password == password) {
      _currentUser = AuthUser(
        role: UserRole.teacher,
        id: teacher.teacherId,
        name: teacher.name,
        teacher: teacher,
      );
      return _currentUser;
    }

    // Student login (by unique ID)
    final student =
        DatabaseService.getStudentById(usernameOrId.trim().toUpperCase());
    if (student != null) {
      _currentUser = AuthUser(
        role: UserRole.student,
        id: student.studentId,
        name: student.name,
        student: student,
      );
      return _currentUser;
    }

    return null;
  }

  static void logout() => _currentUser = null;
}
