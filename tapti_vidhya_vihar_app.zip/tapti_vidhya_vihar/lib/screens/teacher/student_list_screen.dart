import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../models/models.dart';
import '../../services/auth_service.dart';
import '../../services/database_service.dart';
import '../../utils/app_theme.dart';
import '../../widgets/common_widgets.dart';
import 'add_student_screen.dart';
import 'student_detail_screen.dart';

class StudentListScreen extends StatefulWidget {
  const StudentListScreen({super.key});

  @override
  State<StudentListScreen> createState() => _StudentListScreenState();
}

class _StudentListScreenState extends State<StudentListScreen> {
  List<Student> _students = [];
  List<Student> _filtered = [];
  String _search = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() {
    final teacher = AuthService.currentUser?.teacher;
    List<Student> students;
    if (teacher?.assignedClass != null) {
      students = DatabaseService.getStudentsByClass(teacher!.assignedClass!);
    } else {
      // Show only students added by this teacher
      students = DatabaseService.getStudents()
          .where(
              (s) => s.addedByTeacherId == AuthService.currentUser?.id)
          .toList()
        ..sort((a, b) => a.name.compareTo(b.name));
    }
    setState(() {
      _students = students;
      _applyFilter();
    });
  }

  void _applyFilter() {
    setState(() {
      _filtered = _search.isEmpty
          ? List.from(_students)
          : _students
              .where((s) =>
                  s.name
                      .toLowerCase()
                      .contains(_search.toLowerCase()) ||
                  s.studentId
                      .toLowerCase()
                      .contains(_search.toLowerCase()))
              .toList();
    });
  }

  Future<void> _deleteStudent(Student s) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Delete ${s.name}?',
            style: GoogleFonts.roboto(
                fontWeight: FontWeight.w700,
                color: AppTheme.absentColor)),
        content:
            const Text('All attendance records will also be removed.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.absentColor),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (confirm == true) {
      await DatabaseService.deleteAttendanceForStudent(s.studentId);
      await DatabaseService.deleteStudent(s.studentId);
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    final teacher = AuthService.currentUser?.teacher;

    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        title: Text(
            'Students${teacher?.assignedClass != null ? ' — Class ${teacher!.assignedClass}' : ''}'),
        backgroundColor: AppTheme.primary,
        actions: [
          IconButton(
            icon: const Icon(Icons.person_add_alt_1),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (_) => const AddStudentScreen()),
            ).then((_) => _load()),
          ),
        ],
      ),
      body: Column(
        children: [
          // Search
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              onChanged: (v) {
                _search = v;
                _applyFilter();
              },
              decoration: const InputDecoration(
                hintText: 'Search students...',
                prefixIcon:
                    Icon(Icons.search, color: AppTheme.primary),
              ),
            ),
          ),

          // Count
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Text(
                  '${_filtered.length} student(s)',
                  style: GoogleFonts.roboto(
                      fontSize: 13, color: AppTheme.textSecondary),
                ),
              ],
            ),
          ),
          const SizedBox(height: 4),

          Expanded(
            child: _filtered.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.school_outlined,
                            size: 60,
                            color: AppTheme.primary.withOpacity(0.3)),
                        const SizedBox(height: 12),
                        Text(
                          _search.isNotEmpty
                              ? 'No results found'
                              : 'No students yet',
                          style: GoogleFonts.roboto(
                              color: AppTheme.textSecondary,
                              fontSize: 15),
                        ),
                        if (_search.isEmpty) ...[
                          const SizedBox(height: 8),
                          ElevatedButton.icon(
                            onPressed: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) =>
                                      const AddStudentScreen()),
                            ).then((_) => _load()),
                            icon: const Icon(Icons.person_add),
                            label: const Text('Add First Student'),
                          ),
                        ],
                      ],
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.fromLTRB(12, 8, 12, 80),
                    itemCount: _filtered.length,
                    itemBuilder: (ctx, i) {
                      final s = _filtered[i];
                      return Card(
                        margin: const EdgeInsets.only(bottom: 8),
                        child: ListTile(
                          contentPadding: const EdgeInsets.symmetric(
                              horizontal: 14, vertical: 6),
                          leading: StudentAvatar(
                              photoPath: s.photoPath,
                              name: s.name,
                              radius: 24),
                          title: Text(s.name,
                              style: GoogleFonts.roboto(
                                  fontWeight: FontWeight.w600)),
                          subtitle: Column(
                            crossAxisAlignment:
                                CrossAxisAlignment.start,
                            children: [
                              Text(
                                'ID: ${s.studentId}',
                                style: GoogleFonts.roboto(
                                    fontSize: 12,
                                    color: AppTheme.textSecondary),
                              ),
                              ClassChip(label: s.classDiv),
                            ],
                          ),
                          isThreeLine: true,
                          trailing: PopupMenuButton(
                            icon: const Icon(Icons.more_vert,
                                color: AppTheme.textSecondary),
                            itemBuilder: (_) => [
                              const PopupMenuItem(
                                  value: 'view',
                                  child: Row(children: [
                                    Icon(Icons.visibility_outlined,
                                        size: 18),
                                    SizedBox(width: 8),
                                    Text('View Profile')
                                  ])),
                              const PopupMenuItem(
                                  value: 'edit',
                                  child: Row(children: [
                                    Icon(Icons.edit_outlined,
                                        size: 18),
                                    SizedBox(width: 8),
                                    Text('Edit')
                                  ])),
                              const PopupMenuItem(
                                  value: 'delete',
                                  child: Row(children: [
                                    Icon(Icons.delete_outline,
                                        size: 18,
                                        color: AppTheme.absentColor),
                                    SizedBox(width: 8),
                                    Text('Delete',
                                        style: TextStyle(
                                            color: AppTheme.absentColor))
                                  ])),
                            ],
                            onSelected: (v) {
                              if (v == 'view') {
                                Navigator.push(
                                  ctx,
                                  MaterialPageRoute(
                                      builder: (_) =>
                                          StudentDetailScreen(
                                              student: s)),
                                ).then((_) => _load());
                              } else if (v == 'edit') {
                                Navigator.push(
                                  ctx,
                                  MaterialPageRoute(
                                      builder: (_) => AddStudentScreen(
                                          editing: s)),
                                ).then((_) => _load());
                              } else if (v == 'delete') {
                                _deleteStudent(s);
                              }
                            },
                          ),
                          onTap: () => Navigator.push(
                            ctx,
                            MaterialPageRoute(
                                builder: (_) =>
                                    StudentDetailScreen(student: s)),
                          ).then((_) => _load()),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
