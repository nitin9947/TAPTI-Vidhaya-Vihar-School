import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:uuid/uuid.dart';
import '../../models/models.dart';
import '../../services/database_service.dart';
import '../../utils/app_theme.dart';
import '../../widgets/common_widgets.dart';

class ClassManagementScreen extends StatefulWidget {
  const ClassManagementScreen({super.key});

  @override
  State<ClassManagementScreen> createState() =>
      _ClassManagementScreenState();
}

class _ClassManagementScreenState extends State<ClassManagementScreen> {
  List<SchoolClass> _classes = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() =>
      setState(() => _classes = DatabaseService.getClasses()
        ..sort((a, b) => a.className.compareTo(b.className)));

  void _showAddClassDialog() {
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Add New Class',
            style: GoogleFonts.roboto(
                fontWeight: FontWeight.w700, color: AppTheme.primary)),
        content: TextField(
          controller: ctrl,
          keyboardType: TextInputType.number,
          decoration: InputDecoration(
            labelText: 'Class Name (e.g. 8, 9, 10)',
            prefixIcon:
                const Icon(Icons.class_, color: AppTheme.primary),
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              final name = ctrl.text.trim();
              if (name.isEmpty) return;
              final existing = DatabaseService.getClasses()
                  .any((c) => c.className == name);
              if (existing) {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text('Class $name already exists')));
                return;
              }
              final sc = SchoolClass(
                classId: const Uuid().v4(),
                className: name,
                divisions: [],
              );
              await DatabaseService.saveClass(sc);
              Navigator.pop(context);
              _load();
            },
            child: const Text('Add Class'),
          ),
        ],
      ),
    );
  }

  void _showAddDivisionDialog(SchoolClass sc) {
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Add Division to Class ${sc.className}',
            style: GoogleFonts.roboto(
                fontWeight: FontWeight.w700, color: AppTheme.primary)),
        content: TextField(
          controller: ctrl,
          textCapitalization: TextCapitalization.characters,
          decoration: InputDecoration(
            labelText: 'Division (e.g. A, B, C)',
            prefixIcon:
                const Icon(Icons.segment, color: AppTheme.primary),
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              final div = ctrl.text.trim().toUpperCase();
              if (div.isEmpty) return;
              if (sc.divisions.contains(div)) {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text(
                        'Division $div already exists in Class ${sc.className}')));
                return;
              }
              await DatabaseService.addDivisionToClass(sc.classId, div);
              Navigator.pop(context);
              _load();
            },
            child: const Text('Add Division'),
          ),
        ],
      ),
    );
  }

  void _deleteClass(SchoolClass sc) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Delete Class ${sc.className}?',
            style: GoogleFonts.roboto(
                fontWeight: FontWeight.w700, color: AppTheme.absentColor)),
        content: Text(
            'This will also remove all divisions. Students in this class will need to be reassigned.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.absentColor),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (confirm == true) {
      await DatabaseService.deleteClass(sc.classId);
      _load();
    }
  }

  void _removeDivision(SchoolClass sc, String div) async {
    await DatabaseService.removeDivisionFromClass(sc.classId, div);
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        title: const Text('Class & Division Management'),
        backgroundColor: AppTheme.primary,
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showAddClassDialog,
        icon: const Icon(Icons.add),
        label: const Text('Add Class'),
        backgroundColor: AppTheme.primary,
      ),
      body: _classes.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.class_outlined,
                      size: 64,
                      color: AppTheme.primary.withOpacity(0.3)),
                  const SizedBox(height: 16),
                  Text(
                    'No classes created yet',
                    style: GoogleFonts.roboto(
                        color: AppTheme.textSecondary, fontSize: 16),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Tap + to add a class',
                    style: GoogleFonts.roboto(
                        color: AppTheme.textSecondary, fontSize: 13),
                  ),
                ],
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 80),
              itemCount: _classes.length,
              itemBuilder: (ctx, i) {
                final sc = _classes[i];
                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Class Header
                        Row(
                          children: [
                            Container(
                              width: 44,
                              height: 44,
                              decoration: BoxDecoration(
                                color: AppTheme.gold.withOpacity(0.15),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Center(
                                child: Text(
                                  sc.className,
                                  style: GoogleFonts.roboto(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w800,
                                    color: AppTheme.goldDark,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Class ${sc.className}',
                                    style: GoogleFonts.roboto(
                                      fontWeight: FontWeight.w700,
                                      fontSize: 16,
                                    ),
                                  ),
                                  Text(
                                    '${sc.divisions.length} division(s)',
                                    style: GoogleFonts.roboto(
                                        fontSize: 12,
                                        color: AppTheme.textSecondary),
                                  ),
                                ],
                              ),
                            ),
                            IconButton(
                              icon: const Icon(Icons.add_circle_outline,
                                  color: AppTheme.presentColor),
                              onPressed: () =>
                                  _showAddDivisionDialog(sc),
                              tooltip: 'Add Division',
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete_outline,
                                  color: AppTheme.absentColor),
                              onPressed: () => _deleteClass(sc),
                              tooltip: 'Delete Class',
                            ),
                          ],
                        ),

                        if (sc.divisions.isNotEmpty) ...[
                          const SizedBox(height: 12),
                          const GoldDivider(),
                          const SizedBox(height: 8),
                          Text(
                            'Divisions',
                            style: GoogleFonts.roboto(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: AppTheme.textSecondary,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: sc.divisions.map((d) {
                              return Chip(
                                label: Text(
                                  '${sc.className}$d',
                                  style: GoogleFonts.roboto(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w600,
                                      color: AppTheme.primary),
                                ),
                                backgroundColor:
                                    AppTheme.primary.withOpacity(0.08),
                                deleteIcon: const Icon(Icons.close,
                                    size: 14,
                                    color: AppTheme.absentColor),
                                onDeleted: () =>
                                    _removeDivision(sc, d),
                                side: BorderSide(
                                    color: AppTheme.primary
                                        .withOpacity(0.2)),
                              );
                            }).toList(),
                          ),
                        ],
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}
